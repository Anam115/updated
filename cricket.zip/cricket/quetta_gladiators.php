<?php
include 'admin/db.php';
$team_id = 1; // Peshawar Zalmi

// Get captain
$captain_result = $conn->query("SELECT * FROM psl_players WHERE team_id = $team_id AND role = 'Captain' LIMIT 1");
$captain = $captain_result->fetch_assoc();

// Get all players
$players = $conn->query("SELECT * FROM psl_players WHERE team_id = $team_id");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Peshawar Zalmi Squad</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .card {
      position: relative;
      overflow: hidden;
    }