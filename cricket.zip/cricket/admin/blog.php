<?php
$conn = new mysqli("localhost", "root", "", "pak_cricket");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM blog_posts ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Cricket Blog</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-900">
    <div class="max-w-4xl mx-auto p-6">
        <h1 class="text-3xl font-bold mb-6">Latest Blog Posts</h1>
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="bg-white shadow p-4 mb-4 rounded">
                <h2 class="text-2xl font-semibold mb-2"><?= $row['title'] ?></h2>
                <p class="text-gray-700">
                    <?= nl2br(substr($row['content'], 0, 150)) ?>...
                </p>
                <a href="post.php?id=<?= $row['id'] ?>" class="text-blue-600 underline mt-2 inline-block">Read More</a>
                <p class="text-sm text-gray-500 mt-2">Posted on: <?= $row['created_at'] ?></p>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>
