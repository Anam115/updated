<?php
// DB connection
$conn = new mysqli("localhost", "root", "", "pak_cricket");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_ip = $_SERVER['REMOTE_ADDR'];

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid post ID.");
}

$post_id = (int) $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reaction'])) {
    $reaction = $conn->real_escape_string($_POST['reaction']);

    $check = $conn->query("SELECT * FROM blog_likes WHERE post_id = $post_id AND user_ip = '$user_ip'");
    if ($check->num_rows === 0) {
        $conn->query("INSERT INTO blog_likes (post_id, user_ip, reaction) VALUES ($post_id, '$user_ip', '$reaction')");
    } else {
        
        $conn->query("UPDATE blog_likes SET reaction = '$reaction' WHERE post_id = $post_id AND user_ip = '$user_ip'");
    }

    header("Location: post.php?id=$post_id");
    exit;
}

$post_result = $conn->query("SELECT * FROM blog_posts WHERE id = $post_id");
if ($post_result->num_rows === 0) {
    die("Post not found.");
}
$post = $post_result->fetch_assoc();

$reaction_types = ['like' => '👍', 'love' => '❤️', 'funny' => '😆', 'wow' => '😮', 'sad' => '😢', 'angry' => '😡'];
$reaction_counts = [];
foreach ($reaction_types as $key => $emoji) {
    $count_result = $conn->query("SELECT COUNT(*) AS count FROM blog_likes WHERE post_id = $post_id AND reaction = '$key'");
    $reaction_counts[$key] = $count_result->fetch_assoc()['count'] ?? 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment'])) {
    $comment = $conn->real_escape_string($_POST['comment']);
    $conn->query("INSERT INTO blog_comments (post_id, comment) VALUES ($post_id, '$comment')");
}

$comments = $conn->query("SELECT * FROM blog_comments WHERE post_id = $post_id ORDER BY created_at DESC");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title><?= htmlspecialchars($post['title']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
    <div class="max-w-3xl mx-auto bg-white p-6 rounded shadow">
        <h1 class="text-3xl font-bold mb-4"><?= htmlspecialchars($post['title']) ?></h1>
        <p class="text-gray-700 mb-6"><?= nl2br(htmlspecialchars($post['content'])) ?></p>

        <!-- Reaction Buttons -->
        <div class="mb-6">
            <form method="POST" class="flex gap-3 flex-wrap">
                <?php foreach ($reaction_types as $key => $emoji): ?>
                    <button name="reaction" value="<?= $key ?>" class="px-2 py-1 rounded bg-gray-100 hover:bg-blue-100">
                        <?= $emoji ?> (<?= $reaction_counts[$key] ?>)
                    </button>
                <?php endforeach; ?>
            </form>
        </div>

        <!-- Comment Form -->
        <form method="POST" class="mb-6">
            <textarea name="comment" rows="3" required class="w-full border p-2 rounded" placeholder="Write a comment..."></textarea>
            <button type="submit" class="mt-2 px-4 py-2 bg-blue-600 text-white rounded">Post Comment</button>
        </form>

        <!-- Comments -->
        <h2 class="text-xl font-semibold mb-2">Comments</h2>
        <div class="space-y-3">
            <?php if ($comments->num_rows > 0): ?>
                <?php while ($row = $comments->fetch_assoc()): ?>
                    <div class="bg-gray-100 p-2 rounded">
                        <?= htmlspecialchars($row['comment']) ?>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="text-gray-500">No comments yet. Be the first!</p>
            <?php endif; ?>
        </div>

        <a href="blog.php" class="mt-6 inline-block text-blue-500 underline">← Back to Blog</a>
    </div>
</body>
</html>
